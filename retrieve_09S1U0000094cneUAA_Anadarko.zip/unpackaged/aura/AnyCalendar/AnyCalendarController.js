({
    scriptsLoaded : function(component, event, helper) {
        helper.getEvents(component, event);
    }
})